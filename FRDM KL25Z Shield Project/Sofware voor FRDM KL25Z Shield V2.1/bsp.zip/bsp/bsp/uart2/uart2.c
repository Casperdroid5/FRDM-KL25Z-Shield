#include "UART2.h"

static queue_t TxQ, RxQ;

void uart2_init(void)
{  
    // enable clock to UART and Port B and Port E
    SIM->SCGC4 |= SIM_SCGC4_UART2_MASK;
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK;
    SIM->SCGC5 |= SIM_SCGC5_PORTE_MASK;
    
    // Select digital IO pins
    PORTB->PCR[10] = PORT_PCR_MUX(1);
    PORTB->PCR[11] = PORT_PCR_MUX(1);
    
    // PTB10: STATE
    // PTB11: ENABLE
    PTB->PDDR &= ~(1<<10);
    PTB->PDDR |= (1<<11);
    PTB->PCOR = (1<<11);
  
    // select UART pins
    PORTE->PCR[22] = PORT_PCR_ISF_MASK | PORT_PCR_MUX(4);
    PORTE->PCR[23] = PORT_PCR_ISF_MASK | PORT_PCR_MUX(4);
  
    UART2->C2 &=  ~(UART_C2_TE_MASK | UART_C2_RE_MASK);
        
    // Set baud rate to baud rate
    uint32_t divisor = 240000UL/(96*16);
    UART2->BDH = UART_BDH_SBR(divisor>>8);
    UART2->BDL = UART_BDL_SBR(divisor);
    
    // No parity, 8 bits, one stop bit, other settings;
    UART2->C1 = 0; 
    UART2->S2 = 0;
    UART2->C3 = 0;
    
    // Enable transmitter and receiver but not interrupts
    UART2->C2 = UART_C2_TE_MASK | UART_C2_RE_MASK;
    
    NVIC_SetPriority(UART2_IRQn, 128); // 0, 64, 128 or 192
    NVIC_ClearPendingIRQ(UART2_IRQn); 
    NVIC_EnableIRQ(UART2_IRQn);

    UART2->C2 |= UART_C2_RIE_MASK;
    
    q_init(&TxQ);
    q_init(&RxQ);  
}

void UART2_IRQHandler(void)
{
    uint8_t c;
  
    NVIC_ClearPendingIRQ(UART2_IRQn);
  
    if (UART2->S1 & UART_S1_TDRE_MASK)
    {
        // can send another character
        if(q_dequeue(&TxQ, &c))
        {
            UART2->D = c;
        } 
        else
        {
            // queue is empty so disable transmitter
            UART2->C2 &= ~UART_C2_TIE_MASK;
        }
    }
    if (UART2->S1 & UART_S1_RDRF_MASK)
    {
        c = UART2->D;
        
        if(!q_enqueue(&RxQ, c))
        {
            // error - queue full.
            while (1)
            {;}
        }
    }
    if (UART2->S1 & (UART_S1_OR_MASK |UART_S1_NF_MASK | 
                     UART_S1_FE_MASK | UART_S1_PF_MASK))
    {
        // handle the error
        // clear the flag
        /*
        UART2->S1 = UART_S1_OR_MASK | UART_S1_NF_MASK | 
            UART_S1_FE_MASK | UART_S1_PF_MASK;
        */
    }
}

void uart2_send_string(char * str)
{
    // Enqueue string
    while (*str != '\0') 
    { 
        // Wait for space to open up
        while(!q_enqueue(&TxQ, *str))
        {;}
            
        str++;
    }
    
    // Start transmitter if it isn't already running
    if (!(UART2->C2 & UART_C2_TIE_MASK)) 
    {
        UART2->C2 |= UART_C2_TIE_MASK;
    }
}

uint32_t uart2_num_rx_chars_available(void)
{
    return q_size(&RxQ);
}

char uart2_get_char(void) 
{
    uint8_t c=0;
    
    // Wait for data.
    // If waiting is not desired, call the function
    // uart2_num_rx_chars_available() first to make sure data is available.
    while(!q_dequeue(&RxQ, &c))
    {;}
    
    return (char)c;
}

void uart2_put_char(char c) 
{
    // Wait for space to open up
    while(!q_enqueue(&TxQ, c))
    {;}
        
    // Start transmitter if it isn't already running
    if (!(UART2->C2 & UART_C2_TIE_MASK)) 
    {
        UART2->C2 |= UART_C2_TIE_MASK;
    }        
}
