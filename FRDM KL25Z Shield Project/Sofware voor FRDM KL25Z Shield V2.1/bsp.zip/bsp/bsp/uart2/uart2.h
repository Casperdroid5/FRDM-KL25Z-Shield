#ifndef UART2_H
#define UART2_H

#include <stdint.h>
#include <MKL25Z4.H>
#include "queue.h"

void uart2_init(void);
uint32_t uart2_num_rx_chars_available(void);
char uart2_get_char(void);
void uart2_put_char(char c);
void uart2_send_string(char *str);

#endif
