/*! ***************************************************************************
 *
 * \brief     Low level driver for the LEDs
 * \file      leds.c
 * \author    Hugo Arends
 * \date      April 2021
 *
 * \copyright 2021 HAN University of Applied Sciences. All Rights Reserved.
 *            \n\n
 *            Permission is hereby granted, free of charge, to any person
 *            obtaining a copy of this software and associated documentation
 *            files (the "Software"), to deal in the Software without
 *            restriction, including without limitation the rights to use,
 *            copy, modify, merge, publish, distribute, sublicense, and/or sell
 *            copies of the Software, and to permit persons to whom the
 *            Software is furnished to do so, subject to the following
 *            conditions:
 *            \n\n
 *            The above copyright notice and this permission notice shall be
 *            included in all copies or substantial portions of the Software.
 *            \n\n
 *            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *            EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *            OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *            NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *            HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *            WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *            FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *            OTHER DEALINGS IN THE SOFTWARE.
 *
 *****************************************************************************/
#include "leds.h"

static PORT_Type * port_mapping[N_LEDS] = {PORTC, PORTC, PORTA, PORTA, PORTA, PORTD};
static GPIO_Type * gpio_mapping[N_LEDS] = {PTC,   PTC,   PTA,   PTA,   PTA,   PTD};
static uint8_t     pin_mapping[N_LEDS]  = {9,     8,     5,     13,     12,    4};

/*!
 * \brief Initialises the LEDs on the shield
 *
 * This functions initializes the LEDs on the shield.
 *
 * \todo Implement both a GPIO and a PWM option?
 */
void leds_init(void)
{
    // Enable clocks to PORTs
    SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK | 
                  SIM_SCGC5_PORTC_MASK | 
                  SIM_SCGC5_PORTA_MASK;
    
    // Configure all pins as follows:
    // - MUX[2:0] = 001 : Alternative 1 (GPIO)
    // - DSE = 0 : Low drive strength
    // - PFE = 0 : Passive input filter is disabled
    // - SRE = 0 : Fast slew rate is configured
    // - PE = 0 : Internal pullup or pulldown resistor is not enabled
    for(int i=0; i<N_LEDS; i++)
    {
        port_mapping[i]->PCR[pin_mapping[i]] = PORT_PCR_MUX(1);
    }

    // Set port pins to outputs
    for(int i=0; i<N_LEDS; i++)
    {
        gpio_mapping[i]->PDDR |= (1<<pin_mapping[i]);
    }
    
    // Turn off the LEDs
    for(int i=0; i<N_LEDS; i++)
    {
        gpio_mapping[i]->PCOR = (1<<pin_mapping[i]);
    }
}

/*!
 * \brief Turns on an LED
 *
 * This functions switches on an LED.
 *
 * \param[in]  led  LED that will switch on, must be of type ::led_t
 */
void leds_on(const led_t led)
{
    gpio_mapping[led]->PSOR = (1<<pin_mapping[led]);
}

/*!
 * \brief Turns off an LED
 *
 * This functions switches off an LED.
 *
 * \param[in]  led  LED that will switch off, must be of type ::led_t
 */
void leds_off(const led_t led)
{
    gpio_mapping[led]->PCOR = (1<<pin_mapping[led]);
}

/*!
 * \brief Toggles an LED
 *
 * This functions toggles an LED.
 *
 * \param[in]  led  LED that will toggle, must be of type ::led_t
 */
void leds_toggle(const led_t led)
{
    gpio_mapping[led]->PTOR = (1<<pin_mapping[led]);
}
