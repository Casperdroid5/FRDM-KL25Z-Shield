/*! ***************************************************************************
 *
 * \brief     Touch Sensing Input (TSI) low level peripheral driver
 * \file      tsi.h
 * \author    Hugo Arends
 * \date      May 2021
 *
 * \remark    On the FRDM-KL25Z, two Touch Sense Input (TSI) signals, TSI0_CH9 
 *            and TSI0_CH10, are connected to capacitive electrodes configured 
 *            as a touch slider.
 *
 * \copyright 2021 HAN University of Applied Sciences. All Rights Reserved.
 *            \n\n
 *            Permission is hereby granted, free of charge, to any person
 *            obtaining a copy of this software and associated documentation
 *            files (the "Software"), to deal in the Software without
 *            restriction, including without limitation the rights to use,
 *            copy, modify, merge, publish, distribute, sublicense, and/or sell
 *            copies of the Software, and to permit persons to whom the
 *            Software is furnished to do so, subject to the following
 *            conditions:
 *            \n\n
 *            The above copyright notice and this permission notice shall be
 *            included in all copies or substantial portions of the Software.
 *            \n\n
 *            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *            EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *            OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *            NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *            HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *            WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *            FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *            OTHER DEALINGS IN THE SOFTWARE.
 *
 *****************************************************************************/
#ifndef TSI_H
#define TSI_H

/// Value for a touch detected by the TSI
typedef enum
{
    T_NO,     ///< No touch detected
    T_LEFT,   ///< Touch detected on the left side of the slider
    T_CENTER, ///< Touch detected on the center of the slider
    T_RIGHT,  ///< Touch detected on the right side of the slider
}touch_t;

/// Value for a swipe
typedef enum
{
    S_NO,   ///< No swipe detected
    S_UP,   ///< Swipe up detected
    S_DOWN, ///< Swipe down detected
}swipe_t;

extern volatile touch_t touch;
extern volatile swipe_t swipe;

void tsi_init(void);
void tsi_swipe_handler(void);

#endif // TSI_H
