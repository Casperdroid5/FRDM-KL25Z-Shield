var searchData=
[
  ['rgb_5finit_152',['rgb_init',['../rgb_8c.html#a5aa509ed3a4cfe6f812692e248618a51',1,'rgb_init(void):&#160;rgb.c'],['../rgb_8h.html#a5aa509ed3a4cfe6f812692e248618a51',1,'rgb_init(void):&#160;rgb.c']]],
  ['rgb_5fonoff_153',['rgb_onoff',['../rgb_8c.html#a7cedb5f135ff9daff84faefb1234276d',1,'rgb_onoff(const bool r, const bool g, const bool b):&#160;rgb.c'],['../rgb_8h.html#a7cedb5f135ff9daff84faefb1234276d',1,'rgb_onoff(const bool r, const bool g, const bool b):&#160;rgb.c']]],
  ['rgb_5fpwmcontrol_154',['rgb_pwmcontrol',['../rgb_8c.html#acd134878dd82d271bc1638d6107162e7',1,'rgb_pwmcontrol(const uint16_t r, const uint16_t g, const uint16_t b):&#160;rgb.c'],['../rgb_8h.html#acd134878dd82d271bc1638d6107162e7',1,'rgb_pwmcontrol(const uint16_t r, const uint16_t g, const uint16_t b):&#160;rgb.c']]]
];
