var searchData=
[
  ['dialog_5fplain_5f12_5',['Dialog_plain_12',['../fonts_8c.html#a72a8dddc301cb6df0f304fea0b1fb4f2',1,'Dialog_plain_12():&#160;fonts.c'],['../fonts_8h.html#a72a8dddc301cb6df0f304fea0b1fb4f2',1,'Dialog_plain_12():&#160;fonts.c']]],
  ['dialog_5fplain_5f6_6',['Dialog_plain_6',['../fonts_8c.html#ab954f2589a57cb22a48982000945250b',1,'Dialog_plain_6():&#160;fonts.c'],['../fonts_8h.html#ab954f2589a57cb22a48982000945250b',1,'Dialog_plain_6():&#160;fonts.c']]]
];
