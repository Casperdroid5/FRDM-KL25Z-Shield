var searchData=
[
  ['i2c1_5finit_133',['i2c1_init',['../i2c1_8c.html#a2f02f20c4160b3c21987d94ab555f352',1,'i2c1_init(void):&#160;i2c1.c'],['../i2c1_8h.html#a2f02f20c4160b3c21987d94ab555f352',1,'i2c1_init(void):&#160;i2c1.c']]],
  ['i2c1_5fwrite_5fcmd_134',['i2c1_write_cmd',['../i2c1_8c.html#a25a1a69451f1fe01d0e7820b7aa2a003',1,'i2c1_write_cmd(const uint8_t address, const uint8_t cmd[], const uint32_t n):&#160;i2c1.c'],['../i2c1_8h.html#a25a1a69451f1fe01d0e7820b7aa2a003',1,'i2c1_write_cmd(const uint8_t address, const uint8_t cmd[], const uint32_t n):&#160;i2c1.c']]],
  ['i2c1_5fwrite_5fdata_135',['i2c1_write_data',['../i2c1_8c.html#ae1e7242ee3df0497ea8267817c9acbb2',1,'i2c1_write_data(const uint8_t address, const uint8_t data[], const uint32_t n):&#160;i2c1.c'],['../i2c1_8h.html#ae1e7242ee3df0497ea8267817c9acbb2',1,'i2c1_write_data(const uint8_t address, const uint8_t data[], const uint32_t n):&#160;i2c1.c']]]
];
