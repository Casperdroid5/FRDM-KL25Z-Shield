var searchData=
[
  ['n_5fleds_197',['N_LEDS',['../leds_8h.html#ae141ceb34938aab59b3009736e72a427',1,'leds.h']]]
];
