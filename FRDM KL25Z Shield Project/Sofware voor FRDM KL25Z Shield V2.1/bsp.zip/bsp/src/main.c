/*! ***************************************************************************
 *
 * \brief     Example that shows how to use the Board Support Package (BSP)
 * \file      main.c
 * \author    Hugo Arends
 * \date      June 2021
 *
 * \copyright 2021 HAN University of Applied Sciences. All Rights Reserved.
 *            \n\n
 *            Permission is hereby granted, free of charge, to any person
 *            obtaining a copy of this software and associated documentation
 *            files (the "Software"), to deal in the Software without
 *            restriction, including without limitation the rights to use,
 *            copy, modify, merge, publish, distribute, sublicense, and/or sell
 *            copies of the Software, and to permit persons to whom the
 *            Software is furnished to do so, subject to the following
 *            conditions:
 *            \n\n
 *            The above copyright notice and this permission notice shall be
 *            included in all copies or substantial portions of the Software.
 *            \n\n
 *            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *            EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *            OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *            NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *            HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *            WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *            FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *            OTHER DEALINGS IN THE SOFTWARE.
 *
 *****************************************************************************/
#include <MKL25Z4.H>
#include <math.h>
#include <stdio.h>

#include "bsp.h"

// Demos
// 14 : TSI
// 13 : Servo
// 12 : Self test
// 11 : SSD1306 Oled display
// 10 : Potentiometer connectd to ADC and visualized on LCD
//  9 : Touch Sensing Input
//  8 : LEDs
//  7 : switches
//  6 : TCRT5000
//  5 : LCD
//  4 : Using bluetooth module connected to uart2
//  3 : Forwarding data from UART0 to UART1 and vice versa
//  2 : Accelerometer readings shown via UART0
//  1 : RGB LED
//  0 : Counter on UART0 and blinking green LED
#define DEMO 13

/*!
 * \brief Main application
 *
 * This main application shows off all the functions of the shield for the
 * FRDM-KL25Z board.
 */
int main(void)
{
    uart0_init();
    leds_init();
    rgb_init();
    tcrt5000_init();
    lcd_init();
    lcd_clear();
    
    lcd_bl_on(true);
    
    // Blink Green LED
    rgb_on(false, true, false);
    delay_us(100000);
    rgb_on(false, false, false);
    
    ssd1306_init();
    ssd1306_setorientation(1);
    ssd1306_clearscreen();
    ssd1306_update();
    
    // Show contributors
    uart0_send_string("\r\n\r\n");
    uart0_send_string("FRDM-KL25Z BSP demo\r\n");
    uart0_send_string("HAN University of Applied Sciences\r\n");
    uart0_send_string("Contributers:\r\n");
    uart0_send_string(" - Casper Tak\r\n");
    uart0_send_string(" - Hugo Arends\r\n");
    uart0_send_string("\r\n\r\n");
    
    lcd_set_cursor(0,0);
    lcd_print("FRDM-KL25Z BSP");
    
    ssd1306_setfont(Dialog_plain_12);
    ssd1306_clearscreen();
    ssd1306_putstring(0,0,"FRDM-KL25Z BSP");

#if (DEMO == 14)

    tsi_init();
    pit_init();
    
    ssd1306_clearscreen();
    ssd1306_putstring(0,0,"TSI Swipe demo");
    ssd1306_goto(0,0);
    ssd1306_update();
        
    while(1)
    {
        if(swipe == S_UP)
        {
            swipe = S_NO;
            
            ssd1306_terminal("Up\n");
            
            lcd_set_cursor(0,1);
            lcd_print("Up  ");
            
            rgb_on(true, false, false);
            delay_us(100000);
            rgb_on(false, false, false);
        }
        else if(swipe == S_DOWN)
        {
            swipe = S_NO;
            
            ssd1306_terminal("Down\n");
            
            lcd_set_cursor(0,1);
            lcd_print("Down");
            
            rgb_on(false, true, false);
            delay_us(100000);
            rgb_on(false, false, false);
        }
    }

#endif

#if (DEMO == 13)

    servo_init();
    
    while(1)
    {
        servo_move(-90);
        delay_us(1000000);
        servo_move(-45);
        delay_us(1000000);       
        servo_move(0);
        delay_us(1000000);
        servo_move(45);
        delay_us(1000000);
        servo_move(90);
        delay_us(1000000);
        
        servo_move(90);
        delay_us(1000000);
        servo_move(60);
        delay_us(1000000);       
        servo_move(30);
        delay_us(1000000);
        servo_move(0);
        delay_us(1000000);
        servo_move(-30);
        delay_us(1000000);
        servo_move(-60);
        delay_us(1000000);
        servo_move(-90);
        delay_us(1000000);        
    }

#endif

#if (DEMO == 12)

    ssd1306_setfont(Dialog_plain_12);
    ssd1306_clearscreen();
    ssd1306_putstring(0,0,"FRDM-KL25Z BSP");
    ssd1306_putstring(0,12,"Self test");
    ssd1306_putstring(0,32,"Press any key in the");
    ssd1306_putstring(0,46,"terminal to start");
    ssd1306_update();

    while(uart0_num_rx_chars_available() == 0)
    {;}
        
    char c = uart0_get_char();

    // -------------------------------------------------------------------------
    ssd1306_clearscreen();
    ssd1306_putstring(0,0,"Test 1: RGB LED");
    ssd1306_update();
    
    bool done = false;
    while(!done)
    {
        uart0_send_string("Test 1: RGB LED\r\n");
        
        rgb_on(true, false, false);
        delay_us(1000000UL);
        rgb_on(false, true, false);
        delay_us(1000000UL);
        rgb_on(false, false, true);        
        delay_us(1000000UL);
        rgb_on(false, false, false);
        
        uart0_send_string("Did you see the RGB colors:\r\n");
        uart0_send_string(" Y - yes\r\n");
        uart0_send_string(" N - no\r\n");
        uart0_send_string(" A - again\r\n");
        
        while(uart0_num_rx_chars_available() == 0)
        {;}
            
        c = uart0_get_char();
            
        switch(c)
        {
        case 'Y':
        case 'y':
        {
            uart0_send_string("Test passed\r\n");
            done = true;
        }
        break;
        case 'N':
        case 'n':
        {
            uart0_send_string("Test failed\r\n");
            done = true;
        }
        break;
        case 'A':
        case 'a':
        {
            done = false;
        }
        break;
        default:
        {
            uart0_put_char(c);
            uart0_send_string(" is an unknown option\r\n");
        }
        break;
        }
    }    

    // -------------------------------------------------------------------------
    ssd1306_clearscreen();
    ssd1306_putstring(0,0,"Test 2: LEDs");
    ssd1306_update();
    
    done = false;
    while(!done)
    {
        uart0_send_string("Test 2: LEDs\r\n");
        
        for(led_t led = LED1; led <= LED6; led++)
        {
            leds_on(led);
            delay_us(10000);
            leds_off(led);
            delay_us(990000);
        }
        
        uart0_send_string("Did you see all the LEDs blink:\r\n");
        uart0_send_string(" Y - yes\r\n");
        uart0_send_string(" N - no\r\n");
        uart0_send_string(" A - again\r\n");
        
        while(uart0_num_rx_chars_available() == 0)
        {;}
            
        c = uart0_get_char();
            
        switch(c)
        {
        case 'Y':
        case 'y':
        {
            uart0_send_string("Test passed\r\n");
            done = true;
        }
        break;
        case 'N':
        case 'n':
        {
            uart0_send_string("Test failed\r\n");
            done = true;
        }
        break;
        case 'A':
        case 'a':
        {
            done = false;
        }
        break;
        default:
        {
            uart0_put_char(c);
            uart0_send_string(" is an unknown option\r\n");
        }
        break;
        }
    }    
    
    // -------------------------------------------------------------------------
    ssd1306_putstring(0,0,"All tests done");
    ssd1306_update();

    while(1)
    {
        ;
    }
    
#endif

#if (DEMO == 11)

    // Delay to allow the display to start
    delay_us(100000UL);
    ssd1306_init();
    ssd1306_update();
    ssd1306_setorientation(1);
    
    ssd1306_setfont(Dialog_plain_12);
    ssd1306_clearscreen();
    ssd1306_putstring(0,0,"FRDM-KL25Z BSP");
    ssd1306_setfont(Monospaced_plain_10);
    ssd1306_putstring(0,15,"HAN University of");
    ssd1306_putstring(0,27,"Applied Sciences");
    ssd1306_update();
    
    while(1)
    {
        ssd1306_putstring(0,45,"Casper Tak ");
        ssd1306_update();
        delay_us(1000000);
                
        ssd1306_putstring(0,45,"Hugo Arends");
        ssd1306_update();
        delay_us(1000000);
    }

#endif
    
#if (DEMO == 10)

    char str[80];
       
    lcd_init();
    lcd_clear();
    lcd_set_cursor(0,0);
    lcd_print("   POT1 demo    ");
    
    pot1_init();

    while(1)
    {
        // Take one sample
        static float mv;
        mv = pot1_sample_mv();
        
        // Show result in terminal
        sprintf(str, "%7.1f mV\r\n", mv);
        uart0_send_string(str);    
        
        // Map the conversion result from 0 to 16
        uint8_t n = (uint8_t)(((mv / 3330.0f) * 16.0f) + 0.5f);
        
        // Show mapped reuslt on second line of the LCD
        lcd_set_cursor(0,1);
        for(uint8_t i=0; i<n; i++)
        {
            lcd_putchar('#');
        }

        for(uint8_t i=n; i<=16; i++)
        {
            lcd_putchar(' ');
        }
        
        delay_us(200000);        
    }

#endif

#if (DEMO == 9)

    tsi_init();

    while(1)
    {
        touch_t touch = tsi_get_touch();
        rgb_onoff(touch == LEFT, touch == CENTER, touch == RIGHT);
    }

#endif
    
#if (DEMO == 8)

    // LED chaser
    while(1)
    {
        for(led_t led = LED1; led <= LED6; led++)
        {
            leds_on(led);
            delay_us(200000);
            leds_off(led);
        }        
    }

#endif

#if (DEMO == 7)

    leds_init();
    sw_init();

    while(1)
    {
        if(sw_pressed(KEY1))
            leds_on(LED1);
        else
            leds_off(LED1);

        if(sw_pressed(KEY2))
            leds_on(LED2);
        else
            leds_off(LED2);

        if(sw_pressed(KEY3))
            leds_on(LED3);
        else
            leds_off(LED3);

        if(sw_pressed(KEY4))
            leds_on(LED4);
        else
            leds_off(LED4);
    }

#endif

#if (DEMO == 6)

    tcrt5000_init();
    char str[80];

    while(1)
    {
        static uint16_t distance;
        distance = tcrt5000_measure_cm(10);
        sprintf(str, "%05d", distance);
        uart0_send_string(str);
        uart0_send_string("\r\n");
        
        lcd_set_cursor(0,1);
        lcd_print(str);

        leds_on(LED1);
        delay_us(1000);
        leds_off(LED1);
        delay_us(199000);
    }

#endif

#if (DEMO == 5)

    lcd_init();
    lcd_clear();
    lcd_set_cursor(0,0);
    lcd_print(" FRDM-KL25Z demo");
    
    for(int i=0; i<10; i++)
    {
        lcd_bl_on(false);
        delay_us(250000);
        lcd_bl_on(true);
        delay_us(250000);
    }

    while(1)
    {
        lcd_set_cursor(0,1);
        lcd_print("   Created by   ");

        for(uint32_t i=0; i<0xFFFF; i++)
        {
            lcd_bl_pwmcontrol(i);
            delay_us(150);
        }
                
        lcd_set_cursor(0,1);
        lcd_print("   Casper Tak   ");
        delay_us(2000000);
        
        lcd_set_cursor(0,1);
        lcd_print("   Hugo Arends  ");
        delay_us(2000000);
        
        lcd_set_cursor(0,1);
        lcd_print("                ");
        delay_us(1000000);
    }

#endif

#if (DEMO == 4)

    uart2_init();
    
    lcd_set_cursor(0,1);
    lcd_print("Bluetooth demo");

    ssd1306_putstring(0,12,"Bluetooth demo");   
    ssd1306_update();
    
    while(1)
    {
        uart2_send_string("Hello World!\r\n");


        if(uart2_num_rx_chars_available() > 0)
        {
            char c = uart2_get_char();

            // For debugging
            char str[4] = " \r\n";
            str[0] = c;
            uart0_send_string(str);

            if(c == 'g')
            {
                rgb_on(false, true, false);
            }
            if(c == 'o')
            {
                rgb_on(false, false, false);
            }
        }

        delay_us(1000000);
    }

#endif

#if (DEMO == 3)

    uart0_send_string("Demo: Forwarding data from UART0 to UART1 and vice versa\r\n");

    uart1_init();

    uart0_send_string("\r\nFRDM-KL25Z BSP demo for MIC2");
    uart1_send_string("\r\nFRDM-KL25Z BSP demo for MIC2");

    while(1)
    {
        // Forward characters from UART0 to UART1
        while(uart0_num_rx_chars_available() > 0)
        {
            char c = uart0_get_char();

            uart1_put_char(c);

            rgb_on(false, true, false);
            delay_us(100000);
            rgb_on(false, false, false);
        }

        // Forward characters from UART1 to UART0
        while(uart1_num_rx_chars_available() > 0)
        {
            char c = uart1_get_char();

            uart0_put_char(c);

            rgb_on(true, false, false);
            delay_us(100000);
            rgb_on(false, false, false);
        }
    }

#endif

#if (DEMO == 2)

    uart0_send_string("Demo: Accelerometer readings shown via UART0\r\n");

    uart0_send_string("Initializing MMA8451 ");
    if(!mma8451_init())
    {
        // Set pins to GPIO function
        PORTE->PCR[24] &= ~PORT_PCR_MUX_MASK;
        PORTE->PCR[25] &= ~PORT_PCR_MUX_MASK;
        PORTE->PCR[24] |= PORT_PCR_MUX(1);
        PORTE->PCR[25] |= PORT_PCR_MUX(1);

        // Set pins to output
        PTE->PDDR |= (1<<24) | (1<<25);

        // Set pins high
        PTE->PSOR = (1<<24) | (1<<25);

        uart0_send_string("failed\r\n");
        uart0_send_string("Please reset the device\r\n");

        rgb_on(true, false, false);

        while(1)
        {;}
	}
    uart0_send_string("done\r\n");

    // Make sure the time between I2C transfers is > t_BUF (1.3 us)
    delay_us(10);

    // Calibrate
    uart0_send_string("Calibrating MMA8451 ");
    if(!mma8451_calibrate())
    {
        // Set pins to GPIO function
        PORTE->PCR[24] &= ~PORT_PCR_MUX_MASK;
        PORTE->PCR[25] &= ~PORT_PCR_MUX_MASK;
        PORTE->PCR[24] |= PORT_PCR_MUX(1);
        PORTE->PCR[25] |= PORT_PCR_MUX(1);

        // Set pins to output
        PTE->PDDR |= (1<<24) | (1<<25);

        // Set pins high
        PTE->PSOR = (1<<24) | (1<<25);

        uart0_send_string("failed\r\n");
        uart0_send_string("Please reset the device\r\n");

        rgb_on(true, false, false);

        while(1)
        {;}
    }
    uart0_send_string("done\r\n");

    uart0_send_string("TIP: use FreeMASTER to visualize the variables\r\n");

    char str[80];

    while(1)
    {
        delay_us(100000UL);
        

        mma8451_read();
        mma8451_rollpitch();

        // 1 g = 9.80665 m/s^2
        float accelerationx_mss = x_out_g * 9.80665f;

        // Mechanical Filtering Window
        if((accelerationx_mss < 0.06f) && (accelerationx_mss > -0.06f))
        {
            accelerationx_mss = 0;
        }

        // First X integration (simple)
        static float velocityx_ms = 0.0f;
        velocityx_ms += accelerationx_mss * dt;

        // Second X integration (simple)
        static float positionx_m = 0.0f;
        positionx_m += velocityx_ms * dt;

        // Movement end check
        static uint32_t countzerox = 0;
        if(accelerationx_mss == 0)
        {
            countzerox++;
        }
        else
        {
            countzerox = 0;
        }

        if(countzerox >= 10)
        {
            velocityx_ms = 0;
        }

        sprintf(str, "%7.4f %7d %7.4f %7.4f %7.4f %7.4f\r",
            dt, x_out_14_bit, x_out_g, accelerationx_mss, velocityx_ms, positionx_m);
        uart0_send_string(str);

        sprintf(str, "%7.4f %7.4f", x_out_g, accelerationx_mss);
        lcd_set_cursor(0,1);
        lcd_print(str);

        // Light green LED if roll > 45 degrees
        // Light blue LED if pitch > 45 degrees
        rgb_on(false, (fabsf(roll) > 45)? 1:0, (fabsf(pitch) > 45)? 1:0);
    }
#endif

#if (DEMO == 1)

    uart0_send_string("Demo: RGB LED\r\n");
    
    lcd_set_cursor(0,1);
    lcd_print("Demo: RGB LED");
    
    ssd1306_putstring(0,12,"Demo: RGB LED");   
    ssd1306_update();

    while(1)
    {
        // Loop from 0 to 7
        // Show bit [2:0] values on the LEDs:
        //  - bit 0: red LED
        //  - bit 1: green LED
        //  - bit 2: blue LED
        for(uint8_t num = 0; num < 8; num++)
        {
            rgb_onoff(num & 1, num & 2, num & 4);
            delay_us(1000000UL);
        }
    }

#endif

#if (DEMO == 0)

    uart0_send_string("Demo: Counter on UART0 and blinking green LED\r\n");

    char str[80];

    while(1)
    {
        // Show the counter
        for(int i=0; i<1000; ++i)
        {
            sprintf(str, "\r%04d", i);
            uart0_send_string(str);

            // Blink the green LED every 100 counts
            if((i % 100) == 0)
            {
                rgb_onoff(0,1,0);
                delay_us(10000UL);
            }

            rgb_onoff(0,0,0);
            
            delay_us(10000);
        }
    }
#endif
}
