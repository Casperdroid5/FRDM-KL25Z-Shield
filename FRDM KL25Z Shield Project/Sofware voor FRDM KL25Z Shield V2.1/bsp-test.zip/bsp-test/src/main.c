/*! ***************************************************************************
 *
 * \brief     Application for testing all the Board Support Package (BSP)
 *            features
 * \file      main.c
 * \author    Hugo Arends
 * \date      July 2021
 *
 * \copyright 2021 HAN University of Applied Sciences. All Rights Reserved.
 *            \n\n
 *            Permission is hereby granted, free of charge, to any person
 *            obtaining a copy of this software and associated documentation
 *            files (the "Software"), to deal in the Software without
 *            restriction, including without limitation the rights to use,
 *            copy, modify, merge, publish, distribute, sublicense, and/or sell
 *            copies of the Software, and to permit persons to whom the
 *            Software is furnished to do so, subject to the following
 *            conditions:
 *            \n\n
 *            The above copyright notice and this permission notice shall be
 *            included in all copies or substantial portions of the Software.
 *            \n\n
 *            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *            EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *            OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *            NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *            HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *            WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *            FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *            OTHER DEALINGS IN THE SOFTWARE.
 *
 *****************************************************************************/
#include <MKL25Z4.H>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "bsp.h"
#include "unity.h"

int stdout_putchar(int ch)
{
    uart0_put_char(ch);
    return ch;
}

int stderr_putchar(int ch)
{
    return stdout_putchar(ch);
}

int stdin_getchar(void)
{
    return uart0_get_char();
}

void test_ssd1306(void);
void test_rgb(void);
void test_leds(void);
void test_lcd(void);
void test_switches(void);
void test_pot1(void);
void test_tcrt5000(void);
void test_tsi(void);
void test_servo(void);
void test_bluetooth(void);

// This function is called before each test
void setUp(void)
{
}

// This function is called after each test
void tearDown(void)
{
}

/*!
 * \brief Main application
 *
 * This main application shows off all the functions of the shield for the
 * FRDM-KL25Z board.
 */
int main(void)
{    
    delay_us(200000);
    uart0_init();
    
    // VT100 code to clear entire screen 
	char cmd1[] = {0x1B, '[', '2', 'J', '\0'}; // Clear screen
	char cmd2[] = {0x1B, '[', 'f', '\0'}; // Cursor home
    printf("%s%s", cmd1, cmd2);
    
    printf("System init done, starting unit tests\r\n");
    
    UNITY_BEGIN();

#if 1
    printf("\r\nUnit test SSD1306 oled display\r\n");
    RUN_TEST(test_ssd1306);
    printf("\r\nUnit test RGB LED\r\n");
    RUN_TEST(test_rgb);
    printf("\r\nUnit test LEDs\r\n");
    RUN_TEST(test_leds);
    printf("\r\nUnit test LCD\r\n");
    RUN_TEST(test_lcd);
    printf("\r\nUnit test switches\r\n");
    RUN_TEST(test_switches);
    printf("\r\nUnit test potentiometer POT1\r\n");
    RUN_TEST(test_pot1);
    printf("\r\nUnit test TCRT5000 IR module\r\n");
    RUN_TEST(test_tcrt5000);
    printf("\r\nUnit test Touch Sense Input\r\n");
    RUN_TEST(test_tsi);
    printf("\r\nUnit test servo motor\r\n");
    RUN_TEST(test_servo);
    printf("\r\nUnit test HC05/06 bluetooth module\r\n");
    RUN_TEST(test_bluetooth);
#endif    
    
    UNITY_END();
    
    while(1)
    {;}
}

void test_ssd1306(void)
{
    ssd1306_init();
    ssd1306_setorientation(1);
    ssd1306_clearscreen();
    ssd1306_update();

    char str[] = "ssd1306 unit test";
    ssd1306_terminal(str);
    
    printf("  Is the following message visible on the oled display: %s? (y/n)\r\n", str);

    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);

    // -------------------------------------------------------------------------
    ssd1306_clearscreen();    
    ssd1306_drawbitmap(bitmap2);
    ssd1306_update();    
    
    printf("  Do you see a light bulb on the left side of the oled display? (y/n)\r\n");

    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);
    
    ssd1306_clearscreen();
    ssd1306_update();    
}

void test_rgb(void)
{
    rgb_init();

    // -------------------------------------------------------------------------
    rgb_on(true, false, false);
    
    printf("  Is the red LED on? (y/n)\r\n");    

    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);
    
    // -------------------------------------------------------------------------
    rgb_on(false, true, false);
    
    printf("  Is the green LED on? (y/n)\r\n");    

    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);
    
    // -------------------------------------------------------------------------
    rgb_on(false, false, true);
    
    printf("  Is the blue LED on? (y/n)\r\n");    

    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);
    
    // -------------------------------------------------------------------------
    rgb_on(false, false, false);
}

void test_leds(void)
{
    leds_init();

    // -------------------------------------------------------------------------
    for(int led=LED1; led<=LED6; led++)
    {
        char str[8];
        sprintf(str, "LED%d", led+1);
        
        leds_on(led);
        
        printf("  Is %s on? (y/n)\r\n", str);    

        char c = tolower(uart0_get_char());
        
        leds_off(led);

        TEST_ASSERT_EQUAL_CHAR_MESSAGE('y', c, str);
    }
}

void test_lcd(void)
{
    lcd_init();
    rgb_init();
    
    lcd_clear();
    
    printf("  Is the LCD backlight blinking? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        lcd_bl_on(false);
        delay_us(200000);
        lcd_bl_on(true);
        delay_us(200000);
    }
    
    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);
    
    
    char str[] = "lcd unit test";
    lcd_print(str);
    
    printf("  Is the following message visible on the LCD: %s? (y/n)\r\n", str);

    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);
    
    lcd_bl_on(false);
    lcd_clear();
}

void test_switches(void)
{
    sw_init();
    leds_init();
    
    for(int key=KEY1; key<=KEY4; key++)
    {
        printf("  Do you see LED%d toggle when pressing KEY%d? (y/n)\r\n", key+1, key+1);
        
        while(uart0_num_rx_chars_available() == 0)
        {
            if(sw_pressed(KEY1))
            {
                leds_on(LED1);
            }
            else
            {
                leds_off(LED1);
            }
            
            if(sw_pressed(KEY2))
            {
                leds_on(LED2);
            }
            else
            {
                leds_off(LED2);
            }
            
            if(sw_pressed(KEY3))
            {
                leds_on(LED3);
            }
            else
            {
                leds_off(LED3);
            }
            
            if(sw_pressed(KEY4))
            {
                leds_on(LED4);
            }
            else
            {
                leds_off(LED4);
            }
        }
        
        leds_off(LED1);
        leds_off(LED2);
        leds_off(LED3);
        leds_off(LED4);
        
        char c = tolower(uart0_get_char());
        
        TEST_ASSERT_EQUAL_CHAR('y', c);
    }
}

void test_pot1(void)
{
    pot1_init();
    ssd1306_init();
    ssd1306_setorientation(1);
    ssd1306_clearscreen();
    ssd1306_update();
    ssd1306_goto(0,0);
    
    printf("  Move the potentiometer to the left. Does the OLED (approximately) show the value 0 mV? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        static float mv;
        mv = pot1_sample_mv();
        
        char str[80];
        sprintf(str, "%7.1f mV\r", mv);
        ssd1306_terminal(str);
    }
    
    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);   

    printf("  Move the potentiometer to the right. Does the OLED (approximately) show the value 3300 mV? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        static float mv;
        mv = pot1_sample_mv();
        
        char str[80];
        sprintf(str, "%7.1f mV\r", mv);
        ssd1306_terminal(str);
    }
    
    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);    
    
    ssd1306_clearscreen();
    ssd1306_update();
}

void test_tcrt5000(void)
{
    tcrt5000_init();
    ssd1306_init();
    ssd1306_setorientation(1);
    ssd1306_clearscreen();
    ssd1306_update();
    ssd1306_goto(0,0);
    
    printf("  Make sure nothing is blocking the sensor. Does the OLED show a value between 0 - 200? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        uint16_t distance;
        distance = tcrt5000_measure_cm(10);
        
        char str[80];
        sprintf(str, "%05d\r", distance);
        ssd1306_terminal(str);
    }
    
    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);   

    printf("  Hold your hand 5 cm from the sensor. Does the OLED show a value between 3000 - 5000? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        uint16_t distance;
        distance = tcrt5000_measure_cm(10);
        
        char str[80];
        sprintf(str, "%05d\r", distance);
        ssd1306_terminal(str);
    }
    
    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c); 
    
    printf("  Hold your hand 1 cm from the sensor. Does the OLED show a value between 30000 - 50000? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        uint16_t distance;
        distance = tcrt5000_measure_cm(10);
        
        char str[80];
        sprintf(str, "%05d\r", distance);
        ssd1306_terminal(str);
    }
    
    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c); 
    
    ssd1306_clearscreen();
    ssd1306_update();
}

void test_tsi(void)
{
    tsi_init();
    pit_init();
    rgb_init();
    
    printf("  Do you see the green LED toggle when touching left? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        if(touch == T_LEFT)
        {
            rgb_on(false, true, false);
        }
        else if (touch == T_CENTER)
        {
            rgb_on(true, false, false);
        }
        else if (touch == T_RIGHT)
        {
            rgb_on(false, false, true);
        }
        else
        {
            rgb_on(false, false, false);
        }
    }
    
    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c); 
    
    
    printf("  Do you see the red LED toggle when touching center? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        if(touch == T_LEFT)
        {
            rgb_on(false, true, false);
        }
        else if (touch == T_CENTER)
        {
            rgb_on(true, false, false);
        }
        else if (touch == T_RIGHT)
        {
            rgb_on(false, false, true);
        }
        else
        {
            rgb_on(false, false, false);
        }
    }
    
    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);   
    
    
    printf("  Do you see the blue LED toggle when touching right? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        if(touch == T_LEFT)
        {
            rgb_on(false, true, false);
        }
        else if (touch == T_CENTER)
        {
            rgb_on(true, false, false);
        }
        else if (touch == T_RIGHT)
        {
            rgb_on(false, false, true);
        }
        else
        {
            rgb_on(false, false, false);
        }
    }
    
    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);   
    
    
    printf("  Do you see the red LED toggle when swiping up (left to right)? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        if(swipe == S_UP)
        {
            swipe = S_NO;
            
            rgb_on(true, false, false);
            delay_us(200000);
        }
        else if(swipe == S_DOWN)
        {
            swipe = S_NO;
            
            rgb_on(false, true, false);
            delay_us(200000);
        }
        else
        {
            rgb_on(false, false, false);
        }
    }
    
    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);      

    
    printf("  Do you see the green LED toggle when swiping down (right to left)? (y/n)\r\n");
    
    while(uart0_num_rx_chars_available() == 0)
    {
        if(swipe == S_UP)
        {
            swipe = S_NO;
            
            rgb_on(true, false, false);
            delay_us(200000);
        }
        else if(swipe == S_DOWN)
        {
            swipe = S_NO;
            
            rgb_on(false, true, false);
            delay_us(200000);
        }
        else
        {
            rgb_on(false, false, false);
        }
    }
    
    rgb_on(false, false, false);
    
    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);      
}

void test_servo(void)
{  
    servo_init();
    
    // -------------------------------------------------------------------------
    servo_move(-90);
    
    printf("  Has the servo stopped in the outer left position? (y/n)\r\n");    

    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);    

    // -------------------------------------------------------------------------
    servo_move(0);
    
    printf("  Has the servo stopped in the center position? (y/n)\r\n");    

    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);    

    // -------------------------------------------------------------------------
    servo_move(90);
    
    printf("  Has the servo stopped in the outer right position? (y/n)\r\n");    

    c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);    
}

void test_bluetooth(void)
{
    uart2_init();
    
    char str1[] = "bluetooth module unit test";
    uart2_send_string(str1);
    uart2_send_string("\r\n");
    
    printf("  Is the following message visible via the bluetooth serial monitor: %s? (y/n)\r\n", str1);

    char c = tolower(uart0_get_char());
    
    TEST_ASSERT_EQUAL_CHAR('y', c);
    
    // -------------------------------------------------------------------------
    
    char str2[] = "unit test";
    
    printf("  Type the following message via the bluetooth serial monitor: %s\r\n", str2);

    char str[32];
    int i=0;
    uint32_t timeout = 0;
    
    while(i<strlen(str2))
    {
        if(uart2_num_rx_chars_available() > 0)
        {
            str[i] = uart2_get_char();
            i++;
            timeout = 0;
        }
        else
        {
            timeout++;
            
            if(timeout > 50)
            {
                printf("  Timeout\r\n");
                break;
            }
        }
            
        delay_us(100000);
    }
    
    str[strlen(str2)] = '\0';
    
    TEST_ASSERT_EQUAL_STRING(str2, str);
}
