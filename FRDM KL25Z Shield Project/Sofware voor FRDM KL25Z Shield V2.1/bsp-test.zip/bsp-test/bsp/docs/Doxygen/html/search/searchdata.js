var indexSectionsWithContent =
{
  0: "bdefiklmnoprstxy",
  1: "bfilmrs",
  2: "ilrs",
  3: "bdfkmsxy",
  4: "lp",
  5: "lo",
  6: "beilnps",
  7: "ft"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros",
  7: "Pages"
};

