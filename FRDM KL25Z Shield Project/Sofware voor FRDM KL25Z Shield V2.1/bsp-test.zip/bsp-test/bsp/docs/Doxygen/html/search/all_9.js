var searchData=
[
  ['off_51',['OFF',['../ssd1306_8h.html#ac7da307bf8e114432ed8c113eee2186aaac132f2982b98bcaa3445e535a03ff75',1,'ssd1306.h']]],
  ['on_52',['ON',['../ssd1306_8h.html#ac7da307bf8e114432ed8c113eee2186aa977d478dacaae531f95695750d1e9d03',1,'ssd1306.h']]]
];
