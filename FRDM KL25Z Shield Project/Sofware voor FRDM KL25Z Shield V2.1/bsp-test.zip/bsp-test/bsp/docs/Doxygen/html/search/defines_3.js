var searchData=
[
  ['lcd_5fcolumns_195',['LCD_COLUMNS',['../lcd__4bit_8h.html#a537e0d54d9ec6c708bd8990c2f4d8e64',1,'lcd_4bit.h']]],
  ['lcd_5frows_196',['LCD_ROWS',['../lcd__4bit_8h.html#a9a59fc4d524d3519a6bd0cb451850a65',1,'lcd_4bit.h']]]
];
