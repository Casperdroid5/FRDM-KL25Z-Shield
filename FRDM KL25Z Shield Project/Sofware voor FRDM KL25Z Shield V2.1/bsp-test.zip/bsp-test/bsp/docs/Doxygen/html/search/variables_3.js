var searchData=
[
  ['kranky_5fregular_5f20_176',['Kranky_Regular_20',['../fonts_8c.html#a075ba90d46277f324dd663d2876eb96c',1,'Kranky_Regular_20():&#160;fonts.c'],['../fonts_8h.html#a075ba90d46277f324dd663d2876eb96c',1,'Kranky_Regular_20():&#160;fonts.c']]]
];
