/*! ***************************************************************************
 *
 * \brief     Low level driver for servo motor
 * \file      servo.c
 * \author    Hugo Arends
 * \date      July 2021

 *
 * \copyright 2021 HAN University of Applied Sciences. All Rights Reserved.
 *            \n\n
 *            Permission is hereby granted, free of charge, to any person
 *            obtaining a copy of this software and associated documentation
 *            files (the "Software"), to deal in the Software without
 *            restriction, including without limitation the rights to use,
 *            copy, modify, merge, publish, distribute, sublicense, and/or sell
 *            copies of the Software, and to permit persons to whom the
 *            Software is furnished to do so, subject to the following
 *            conditions:
 *            \n\n
 *            The above copyright notice and this permission notice shall be
 *            included in all copies or substantial portions of the Software.
 *            \n\n
 *            THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *            EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *            OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *            NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *            HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *            WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *            FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *            OTHER DEALINGS IN THE SOFTWARE.
 *
 *****************************************************************************/
#include "servo.h"

/*!
 * \brief Initialises the servo motor
 *
 * Uses Timer/PWM Module 1 (TPM1)
 */
void servo_init(void)
{
    // Enable clock to PORT B
	SIM->SCGC5 |= SIM_SCGC5_PORTB(0x1);
  
    // Enable clock to TPM1
    SIM->SCGC6 |= SIM_SCGC6_TPM1(0x1);

    // Set pin to TPM1_CH1
	PORTB->PCR[1] = PORT_PCR_MUX(0x3);        

    // Set devide by 16 prescaler
    // Timer is clocked with 48 MHz / 16 = 3 MHz
    TPM1->SC = TPM_SC_PS(0x4);
	
	// Load modulo register
    // PWM frequency should be 50 Hz
    // MOD = (3 MHz / 50 Hz) - 1
	TPM1->MOD = 60000 - 1;
  	
    // Set channel 1 to edge-aligned high-true PWM
    TPM1->CONTROLS[1].CnSC = TPM_CnSC_MSB(0x1) | TPM_CnSC_ELSB(0x1);
  
    // Valid duty cycles are:
    // 0.5 ms = 0.5 * (60000 / 20) = 1500
    // 2.5 ms = 2.5 * (60000 / 20) = 7500
    // Set initial duty cycle: 1.5 ms
    TPM1->CONTROLS[1].CnV = 4500;

    // Start TPM
    TPM1->SC |= TPM_SC_CMOD(0x1); 
}

/*!
 * \brief Moves the servo motor
 *
 * Moves the servo motor to the specified angle. At 0 degrees, the shaft is at
 * center position.
 *
 * \param[in]  angle  Angle in degrees from  -90 to 90
 */
void servo_move(int8_t angle)
{
    // Check limits
    angle = (angle < -90) ? -90 : angle;
    angle = (angle >  90) ?  90 : angle;

    // Calculate the compare value from the angle
    uint16_t val = 7500 - ((angle + 90) * ((7500 - 1500) / 180));
    
    // Set the duty cycle
    TPM1->CONTROLS[1].CnV = val;
}
